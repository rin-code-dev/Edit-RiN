/**
 * @license
 * Copyright 2012 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Image field.  Used for pictures, icons, etc.
 *
 * @class
 */
// Former goog.module ID: Blockly.FieldImage

import type {FieldConfig} from './field.js';
import {Field} from './field.js';
import * as fieldRegistry from './field_registry.js';
import {Msg} from './msg.js';
import {aria} from './utils.js';
import * as dom from './utils/dom.js';
import * as parsing from './utils/parsing.js';
import {Size} from './utils/size.js';
import {Svg} from './utils/svg.js';

/**
 * Class for an image on a block.
 */
export class FieldImage extends Field<string> {
  /**
   * Vertical padding below the image, which is included in the reported height
   * of the field.
   */
  private static readonly Y_PADDING = 1;
  protected readonly imageHeight: number;

  /** The function to be called when this field is clicked. */
  private clickHandler: ((p1: FieldImage) => void) | null = null;

  /** The rendered field's image element. */
  protected imageElement: SVGImageElement | null = null;

  /**
   * Editable fields usually show some sort of UI indicating they are
   * editable. This field should not.
   */
  override readonly EDITABLE = false;

  /**
   * Used to tell if the field needs to be rendered the next time the block is
   * rendered. Image fields are statically sized, and only need to be
   * rendered at initialization.
   */
  protected override isDirty_ = false;

  /** Whether to flip this image in RTL. */
  private flipRtl = false;

  /** Alt text of this image. */
  private altText = '';

  /**
   * @param src The URL of the image.
   *     Also accepts Field.SKIP_SETUP if you wish to skip setup (only used by
   * subclasses that want to handle configuration and setting the field value
   * after their own constructors have run).
   * @param width Width of the image.
   * @param height Height of the image.
   * @param alt Optional alt text for when block is collapsed.
   * @param onClick Optional function to be called when the image is
   *     clicked. If onClick is defined, alt must also be defined.
   * @param flipRtl Whether to flip the icon in RTL.
   * @param config A map of options used to configure the field.
   *     See the [field creation documentation]{@link
   * https://docs.blockly.com/guides/create-custom-blocks/fields/built-in-fields/image/#creation}
   * for a list of properties this parameter supports.
   */
  constructor(
    src: string | typeof Field.SKIP_SETUP,
    width: string | number,
    height: string | number,
    alt?: string,
    onClick?: (p1: FieldImage) => void,
    flipRtl?: boolean,
    config?: FieldImageConfig,
  ) {
    super(Field.SKIP_SETUP);

    const imageHeight = Number(parsing.replaceMessageReferences(height));
    const imageWidth = Number(parsing.replaceMessageReferences(width));
    if (isNaN(imageHeight) || isNaN(imageWidth)) {
      throw Error(
        'Height and width values of an image field must cast to' + ' numbers.',
      );
    }
    if (imageHeight <= 0 || imageWidth <= 0) {
      throw Error(
        'Height and width values of an image field must be greater' +
          ' than 0.',
      );
    }

    /** The size of the area rendered by the field. */
    this.size_ = new Size(imageWidth, imageHeight + FieldImage.Y_PADDING);

    /**
     * Store the image height, since it is different from the field height.
     */
    this.imageHeight = imageHeight;

    if (typeof onClick === 'function') {
      this.clickHandler = onClick;
    }

    if (src === Field.SKIP_SETUP) return;

    if (config) {
      this.configure_(config);
    } else if (isFieldImageConfig(alt)) {
      // Block Factory and some hand-written blocks pass a config object as the
      // fourth argument instead of using the seventh `config` parameter.
      // This is wrong, and typescript will complain about it, but handle it
      // for backwards compatibility.
      this.configure_(alt);
    } else {
      this.flipRtl = !!flipRtl;
      this.altText =
        typeof alt === 'string'
          ? parsing.replaceMessageReferences(alt) || ''
          : '';
    }
    this.setValue(parsing.replaceMessageReferences(src));
  }

  /**
   * Configure the field based on the given map of options.
   *
   * @param config A map of options to configure the field based on.
   */
  protected override configure_(config: FieldImageConfig) {
    super.configure_(config);
    if (config.flipRtl) this.flipRtl = config.flipRtl;
    if (config.alt) {
      this.altText = parsing.replaceMessageReferences(config.alt);
    }
  }

  /**
   * Create the block UI for this image.
   */
  override initView() {
    this.imageElement = dom.createSvgElement(
      Svg.IMAGE,
      {
        'height': this.imageHeight + 'px',
        'width': this.size_.width + 'px',
        'alt': this.altText,
      },
      this.fieldGroup_,
    );
    this.imageElement.setAttributeNS(
      dom.XLINK_NS,
      'xlink:href',
      this.value_ as string,
    );

    if (this.fieldGroup_) {
      dom.addClass(this.fieldGroup_, 'blocklyImageField');
    }

    if (this.clickHandler) {
      this.imageElement.style.cursor = 'pointer';
    }

    this.recomputeAriaContext();
  }

  override updateSize_() {}
  // NOP

  /**
   * Ensure that the input value (the source URL) is a string.
   *
   * @param newValue The input value.
   * @returns A string, or null if invalid.
   */
  protected override doClassValidation_(newValue?: any): string | null {
    if (typeof newValue !== 'string') {
      return null;
    }
    return newValue;
  }

  /**
   * Update the value of this image field, and update the displayed image.
   *
   * @param newValue The value to be saved. The default validator guarantees
   *     that this is a string.
   */
  protected override doValueUpdate_(newValue: string) {
    this.value_ = newValue;
    if (this.imageElement) {
      this.imageElement.setAttributeNS(dom.XLINK_NS, 'xlink:href', this.value_);
    }
    this.recomputeAriaContext();
  }

  /**
   * Get whether to flip this image in RTL
   *
   * @returns True if we should flip in RTL.
   */
  override getFlipRtl(): boolean {
    return this.flipRtl;
  }

  /**
   * Set the alt text of this image.
   *
   * @param alt New alt text.
   */
  setAlt(alt: string | null) {
    if (alt === this.altText) {
      return;
    }
    this.altText = alt || '';
    if (this.imageElement) {
      this.imageElement.setAttribute('alt', this.altText);
    }
  }

  /**
   * Check whether this field should be clickable.
   *
   * @returns Whether this field is clickable.
   */
  isClickable(): boolean {
    // Images are only clickable if they have a click handler and fulfill the
    // contract to be clickable: enabled and attached to an editable block.
    return super.isClickable() && !!this.clickHandler;
  }

  /**
   * If field click is called, and click handler defined,
   * call the handler.
   */
  protected override showEditor_() {
    if (this.clickHandler) {
      this.clickHandler(this);
    }
  }

  /**
   * Set the function that is called when this image  is clicked.
   *
   * @param func The function that is called when the image is clicked, or null
   *     to remove.
   */
  setOnClickHandler(func: ((p1: FieldImage) => void) | null) {
    this.clickHandler = func;
  }

  /**
   * Use the `getText_` developer hook to override the field's text
   * representation.
   * Return the image alt text instead.
   *
   * @returns The image alt text.
   */
  protected override getText_(): string | null {
    return this.altText;
  }

  /**
   * Construct a FieldImage from a JSON arg object,
   * dereferencing any string table references.
   *
   * @param options A JSON object with options (src, width, height, alt, and
   *     flipRtl).
   * @returns The new field instance.
   * @nocollapse
   * @internal
   */
  static override fromJson(options: FieldImageFromJsonConfig): FieldImage {
    if (!options.src || !options.width || !options.height) {
      throw new Error(
        'src, width, and height values for an image field are' +
          'required. The width and height must be non-zero.',
      );
    }
    // `this` might be a subclass of FieldImage if that class doesn't override
    // the static fromJson method.
    return new this(
      options.src,
      options.width,
      options.height,
      undefined,
      undefined,
      undefined,
      options,
    );
  }

  /**
   * Gets an ARIA-friendly label representation of this field's type.
   *
   * Implementations are responsible for, and encouraged to, return a localized
   * version of the ARIA representation of the field's type.
   *
   * @returns An ARIA representation of the field's type or a default if it is
   *     unspecified.
   */
  override getAriaTypeName(): string | null {
    return this.ariaTypeName || Msg['ARIA_TYPE_FIELD_IMAGE'];
  }

  /**
   * Gets an ARIA-friendly label representation of this field's value.
   *
   * Implementations are responsible for, and encouraged to, return a localized
   * version of the ARIA representation of the field's value.
   *
   * @returns An ARIA representation of the field's text, or null if no text is
   *     currently defined or known for the field.
   */
  override getAriaValue(): string | null {
    return this.altText || null;
  }

  /**
   * Computes a descriptive ARIA label to represent this field with configurable
   * verbosity.
   *
   * A 'verbose' label includes type information, if available, whereas a
   * non-verbose label only contains the field's value.
   *
   * Note that this will always return the latest representation of the field's
   * label which may differ from any previously set ARIA label for the field
   * itself. Implementations are largely responsible for ensuring that the
   * field's ARIA label is set correctly at relevant moments in the field's
   * lifecycle (such as when its value changes).
   *
   * Finally, it is never guaranteed that implementations use the label returned
   * by this method for their actual ARIA label. Some implementations may rely
   * on other contexts to convey information like the field's value. Example:
   * checkboxes represent their checked/non-checked status (i.e. value) through
   * a separate ARIA property.
   *
   * Returns an empty string on clickable images (buttons), as we do not want to
   * include image buttons on the block-level ARIA label. When the button is
   * focused the label is set in recomputeAriaContext below.
   *
   * @param includeTypeInfo Whether to include the field's type information in
   *     the returned label, if available.
   */
  override computeAriaLabel(includeTypeInfo: boolean): string {
    const ariaValue = this.getAriaValue();
    if (this.isClickable() || !ariaValue) return '';

    const ariaTypeName = includeTypeInfo ? this.getAriaTypeName() : null;
    if (ariaTypeName) {
      return `${ariaTypeName}: ${ariaValue}`;
    }
    return ariaValue;
  }

  /**
   * Customizes label and sets additional aria state.
   */
  override recomputeAriaContext(): boolean {
    const shouldCustomize = super.recomputeAriaContext();
    if (!shouldCustomize) return false;

    const focusableElement = this.getFocusableElement();

    // The button role is intended to indicate to users that the field has an
    // editing mode that can be activated. The none role is used to
    // prevent screen readers from  reading the content or its descendants.
    // Only clickable image fields are navigable.
    if (!this.isClickable()) {
      aria.setRole(focusableElement, aria.Role.NONE);
      aria.clearState(focusableElement, aria.State.LABEL);
      return false;
    }
    // For clickable images we need to set the label to the alt text here as
    // we have overridden the computeAriaLabel to return an empty string. This
    // will set it at the element level.
    const label = this.getAriaValue() || '';
    aria.setState(focusableElement, aria.State.LABEL, label);
    return true;
  }
}

/**
 * Returns whether a value is a FieldImage config object passed in place of alt
 * text (e.g. `{alt: '*', flipRtl: false}`). You shouldn't do this on purpose,
 * but the block factory generates block definitions in this format.
 *
 * @param value The value to test.
 */
function isFieldImageConfig(value: unknown): value is FieldImageConfig {
  return (
    typeof value === 'object' &&
    value !== null &&
    !Array.isArray(value) &&
    ('alt' in value || 'flipRtl' in value)
  );
}

fieldRegistry.register('field_image', FieldImage);

FieldImage.prototype.DEFAULT_VALUE = '';

/**
 * Config options for the image field.
 */
export interface FieldImageConfig extends FieldConfig {
  flipRtl?: boolean;
  alt?: string;
}

/**
 * fromJson config options for the image field.
 */
export interface FieldImageFromJsonConfig extends FieldImageConfig {
  src?: string;
  width?: number;
  height?: number;
}
